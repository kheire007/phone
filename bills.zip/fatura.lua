ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function FaturaGetBilling (accountId, cb)
  local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.fetchAll([===[
      SELECT * FROM billing WHERE identifier = @identifier
      ]===], { ['@identifier'] = xPlayer.identifier }, cb)
  end 

function getUserFatura(phone_number, firstname, cb)
  MySQL.Async.fetchAll("SELECT firstname, phone_number FROM users WHERE users.firstname = @firstname AND users.phone_number = @phone_number", {
    ['@phone_number'] = phone_number,
	['@firstname'] = firstname
  }, function (data)
    cb(data[1])
  end)
end

RegisterServerEvent('xenknight:fatura_getBilling')
AddEventHandler('xenknight:fatura_getBilling', function(phone_number, firstname)
  local sourcePlayer = tonumber(source)
  if phone_number ~= nil and phone_number ~= "" and firstname ~= nil and firstname ~= "" then
    getUserFatura(phone_number, firstname, function (user)
      local accountId = user and user.id
      FaturaGetBilling(accountId, function (billingg)
        TriggerClientEvent('xenknight:fatura_getBilling', sourcePlayer, billingg)
      end)
    end)
  else
    FaturaGetBilling(nil, function (billingg)
      TriggerClientEvent('xenknight:fatura_getBilling', sourcePlayer, billingg)
    end)
  end
end)


RegisterServerEvent("xenknight:faturapayBill")
AddEventHandler("xenknight:faturapayBill", function(id, sender, amount, target, sharedAccountName, cb)
	local src = source
	local xPlayer = ESX.GetPlayerFromId(src)

	MySQL.Async.fetchAll('SELECT * FROM billing WHERE id = @id', {
		['@id'] = id
	}, function(data)

	
	local target = data[1].target
	local target_type = data[1].target_type
	local amount     = data[1].amount
	
	local xTarget = ESX.GetPlayerFromIdentifier(sender)
	
	if target_type=='player' then
    if xTarget ~= nil then	
        if xPlayer.getBank() >= amount then	

					MySQL.Async.execute('DELETE from billing WHERE id = @id', {
						['@id'] = id
					}, function(rowsChanged)
						xPlayer.removeAccountMoney('bank', amount)
						xTarget.addAccountMoney('bank',amount)

						TriggerClientEvent("esx:showNotification", src, "Faturayı Ödedin $" .. amount)
						TriggerClientEvent("esx:showNotification", xTarget.source, "Bir Faturan Ödendi $" .. amount)

					end)
					
				else
				
					TriggerClientEvent("esx:showNotification", xTarget.source, "Müşterin Bankasında Para Yok.")
					TriggerClientEvent("esx:showNotification", src, "Bankada Para Yok")

				end
				else
	        TriggerClientEvent('esx:showNotification', src, "Oyunda Değil")
    end
	
	else
	
	
TriggerEvent('esx_addonaccount:getSharedAccount', target, function(account)	


 
        if xPlayer.getBank() >= amount then	

					MySQL.Async.execute('DELETE from billing WHERE id = @id', {
						['@id'] = id
					}, function(rowsChanged)
						xPlayer.removeAccountMoney('bank', amount)
						account.addMoney(amount)
                      
					  
					  if xPlayer ~= nil then
						TriggerClientEvent("esx:showNotification", xPlayer.source, "Fatura ödendi $" .. amount)
					   end
                        if xTarget ~= nil then
						TriggerClientEvent("esx:showNotification", xTarget.source, "Fatura Ödendi $" .. amount)
                        end

					end)
					
				else
				if xPlayer ~= nil then
					TriggerClientEvent("esx:showNotification", xPlayer.source, "Yeterli paran yok.")
				end	
					if xTarget ~= nil then
						TriggerClientEvent('esx:showNotification', xTarget.source, "Para yok")
					end


				end
	
end)

end

end)
end)
